//
//  experiment.swift
//  JobFinder
//
//  Created by Apple on 8/6/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import WebKit

struct Landmark {
    
    let placemark: MKPlacemark
    
}
